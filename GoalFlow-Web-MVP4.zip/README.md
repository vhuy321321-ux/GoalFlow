# GoalFlow — Website MVP 4

Website quản lý mục tiêu và công việc, responsive cho điện thoại/máy tính.

## Có gì trong bản này
- Quản lý mục tiêu và công việc, hạn hoàn thành, mức ưu tiên.
- Chia công việc thành việc nhỏ; tiến độ mục tiêu tính theo các việc nhỏ nhất.
- Lịch tuần: xem công việc có hạn theo từng ngày, chuyển tuần trước/tuần sau/về tuần hiện tại.
- Khu vực “Chưa xếp lịch” liệt kê công việc chưa đặt hạn.
- Lưu bằng localStorage, nhập/xuất JSON.

## Chưa có
- Đồng bộ Notion thật.
- Đồng bộ đa thiết bị/tài khoản.

Dữ liệu lưu trong trình duyệt hiện tại. Xuất JSON làm bản sao lưu trước khi thay đổi phiên bản lớn hoặc dọn dữ liệu trình duyệt.

## Chạy
Mở `index.html` hoặc triển khai file này lên GitHub Pages.
